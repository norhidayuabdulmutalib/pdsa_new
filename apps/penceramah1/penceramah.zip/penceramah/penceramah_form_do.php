<?

//$conn->debug=true;

include '../loading.php';

extract($_POST);

/* $id 			= $_POST['id'];

$fld_staff 		= $_POST['fld_staff'];

$fld_alamat 	= $_POST['fld_alamat'];

$fld_tel 		= $_POST['fld_tel'];

$jantina 		= $_POST['jantina'];

$fld_kp 		= $_POST['fld_kp'];

$fld_email 		= $_POST['fld_email'];

$pusatid 		= $_POST['pusatid'];

$is_pensyarah 	= $_POST['is_pensyarah'];

$is_tutor 		= $_POST['is_tutor'];

$is_warden 		= $_POST['is_warden'];

$is_hep 		= $_POST['is_hep'];

$is_gtasmik 		= $_POST['is_gtasmik'];

$flduser_activated = $_POST['flduser_activated'];

$is_user 		= $_POST['is_user'];

$jabatan_id 		= $_POST['jabatan_id'];

$jawatan 		= $_POST['jawatan'];

$gred_id 		= $_POST['gred_id'];



$PageQUERY 	= $_POST['PageQUERY'];

$PageNo = $_POST['PageNo'];

$proses = $_POST['proses']; */



/* if(empty($is_pensyarah)){ $is_pensyarah='N'; }

if(empty($is_tutor)){ $is_tutor='N'; }

if(empty($is_warden)){ $is_warden='N'; }

if(empty($is_hep)){ $is_hep='N'; }

if(empty($is_gtasmik)){ $is_gtasmik='N'; } */

$instypecd = '01';

$insid = str_replace("-","",$insid); 

$insname = strtoupper($insname);

$insdob = DBDate($insdob);

$position = dlookup("_ref_titlegred","f_gred_name","f_gred_code=".tosql($titlegredcd,"Text"));


if(empty($id)){

	echo "insert";

	$id = date("Ymd")."-". uniqid();

	$sql = "INSERT INTO _tbl_instructor(ingenid, insname, titlegredcd, insposition, 

	insorganization, insid, insaddress, inspostcode, insstate, 

	inscountry, inshometel, insmobiletel, insemail, payperhours,

	instypecd, institle, insfaxno, insstatus, 

	insrace, insgender, insnationality, insreligion, insdob,
	
	insbank, insbankbrch, insakaun, insqual, insfieldstudy, 
	
	create_dt, create_by)

	VALUES(".tosql($id,"Text").", ".tosql($insname,"Text").", ".tosql($titlegredcd,"Text").", ".tosql($position,"Text").", 

	".tosql($insorganization,"Text").", ".tosql($insid,"Text").", ".tosql($insaddress,"Text").", ".tosql($inspostcode,"Text").", ".tosql($insstate,"Text").", 

	".tosql($inscountry,"Text").", ".tosql($inshometel,"Text").", ".tosql($insmobiletel,"Text").", ".tosql($insemail,"Text").", ".tosql($payperhours,"Number").", 

	".tosql($instypecd,"Text").", ".tosql($institle,"Text").", ".tosql($insfaxno,"Text").", ".tosql($insstatus,"Text").",  
	
	".tosql($insrace,"Number").", ".tosql($insgender,"Text").", ".tosql($insnationality,"Text").", ".tosql($insreligion,"Text").",
	
	".tosql($insdob,"Text").", ".tosql($insbank,"Text").", ".tosql($insbankbrch,"Number").", ".tosql($insakaun,"Text").", ".tosql($insqual,"Text").",

	".tosql($insfieldstudy,"Number").", ".tosql(date("Y-m-d H:i:s"),"Text").", ".tosql($user,"Text").")";

	$result = $conn->Execute($sql);

	if(!$result){ echo "Invalid query : " . mysql_error(); exit; }

	/* if($is_user=='1'){

		$pass = md5("123");

		$sql1 = "UPDATE _tbl_instructor SET flduser_name=".tosql($user,"Text").", flduser_password=".tosql($pass,"Text")." 

		WHERE staff_id=".tosql($id,"Text");

		$result = $conn->Execute($sql1);

		if(!$result){ echo "Invalid query : " . mysql_error(); exit; }

	} */

	$url = base64_encode('user;penceramah/penceramah_list.php;penceramah;daftar');

	echo "<meta http-equiv=\"refresh\" content=\"1; URL=index.php?data=".$url."\">";

} else {

	echo "Update";

	$sql = "";

	if($proses=='HAPUS'){

		$sql = "UPDATE _tbl_instructor SET insstatus=0,
		
		is_deleted=1, delete_dt='".date("Y-m-d H:i:s")."', delete_by=".tosql("","Text").

		" WHERE ingenid=".tosql($id,"Text");

		$result = $conn->Execute($sql);
		
		$sql = "DELETE FROM _tbl_instructor_akademik WHERE ingenid=".tosql($id,"Text");

		$result = $conn->Execute($sql);
		
		$sql = "DELETE FROM _tbl_instructor_kepakaran WHERE ingenid=".tosql($id,"Text");

		$result = $conn->Execute($sql);

		//exit;

		if(!$result){ echo "Invalid query : " . mysql_error(); exit; }

		$url = base64_encode('user;penceramah/penceramah_list.php;penceramah;daftar');

		echo "<meta http-equiv=\"refresh\" content=\"1; URL=index.php?data=".$url."\">";

	} else {

		$sql = "UPDATE _tbl_instructor SET insname=".tosql($insname,"Text").

		", titlegredcd=".tosql($titlegredcd,"Text").", insposition=".tosql($position,"Text").

		", insorganization=".tosql($insorganization,"Text").", insid=".tosql($insid,"Text").

		", insaddress=".tosql($insaddress,"Text").", inspostcode=".tosql($inspostcode,"Text").

		", insstate=".tosql($insstate,"Text").", inscountry=".tosql($inscountry,"Text").

		", inshometel=".tosql($inshometel,"Text").", insmobiletel=".tosql($insmobiletel,"Text").", insemail=".tosql($insemail,"Text").

		", payperhours=".tosql($payperhours,"Number").", instypecd=".tosql($instypecd,"Text").", institle=".tosql($institle,"Text").", insfaxno=".tosql($insfaxno,"Text").

		", insstatus=".tosql($insstatus,"Text"). ", insrace=".tosql($insrace,"Text"). ", insgender=".tosql($insgender,"Text").
		
		", insnationality=".tosql($insnationality,"Text").", insreligion=".tosql($insreligion,"Text").", insdob=".tosql($insdob,"Text").
		
		", insbank=".tosql($insbank,"Text").", insbankbrch=".tosql($insbankbrch,"Text").", insakaun=".tosql($insakaun,"Text").
		
		", insqual=".tosql($insqual,"Text").", insfieldstudy=".tosql($insfieldstudy,"Text").", update_dt=".tosql(date("Y-m-d H:i:s"),"Text").

		", update_by=".tosql($user,"Text"). " WHERE ingenid=".tosql($id,"Text");



		$result = $conn->Execute($sql);

		//exit;

		if(!$result){ echo "Invalid query : " . mysql_error(); exit; }

		/* if($is_user=='1'){

			$sql_s = "SELECT * FROM _tbl_instructor WHERE staff_id=".tosql($id,"Text")." AND flduser_name IS NULL";

			$rs = $conn->Execute($sql_s);

			if($rs->EOF) {

				$user = str_replace("-","",$rs->fields['fld_kp']);

				$pass = md5("123");

				$sql1 = "UPDATE _tbl_instructor SET flduser_name=".tosql($user,"Text").", flduser_password=".tosql($pass,"Text")." 

				WHERE staff_id=".tosql($id,"Text");

				$result = $conn->Execute($sql1);

				if(!$result){ echo "Invalid query : " . mysql_error(); exit; }

			}

		} */

		//exit;

		$url = base64_encode('user;penceramah/penceramah_list.php;penceramah;daftar;'.$id);

		echo "<meta http-equiv=\"refresh\" content=\"1; URL=index.php?data=".$url."\">";

	}

}

?>